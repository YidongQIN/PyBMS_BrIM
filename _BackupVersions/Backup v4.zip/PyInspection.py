
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ = 'Yidong QIN'

"""
Bridge inspection information
"""

from PyPackOB import *

class Inspection(object):
    def __init__(self):
        pass